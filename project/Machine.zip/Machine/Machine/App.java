package Machine;

public class App {
    public static void main(String[] args) {
        MachineUI ui = new MachineUI();
        ui.menu();
    }
}