package Machine;

public class StockXException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public StockXException(String msg) {
		super(msg);
	}
}

