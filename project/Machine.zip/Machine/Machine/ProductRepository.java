package Machine;

import java.util.Map;

public interface ProductRepository {
    public Map<Integer, String> findAll();
}
