package Machine;

public class MoneyXException extends Exception{
	private static final long serialVersionUID = 1L;
	public MoneyXException(String msg) {
		super(msg);
	}
}
