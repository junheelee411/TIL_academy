package main;

import userInterface.UI;

public class App {
    public static void main(String[] args) {
        // 프로그램 시작
        new UI();
    }
}
