package userInterface;

public class Project_ResearcherUI {

    public void printProjectResearcher() {
        System.out.println("1111 김바보");
        System.out.println("1112 김수열");
    }

    public void addProjectResearcher() {
        System.out.println("연구원 추가 완료 (테스트용)\n");
    }

    public void deleteProjectResearcher() {
        System.out.println("연구원 삭제 완료 (테스트용)\n");
    }
}
