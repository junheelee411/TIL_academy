package administrator;

import db.organization.OrganizationDTO;
import db.project.ProjectDTO;
import db.util.DBConn;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class AdminUI {
    private final AdminDAO dao = new AdminDAO();
    private JFrame frame;

    // 기관 테이블
    private JTable orgTable;
    private DefaultTableModel orgTableModel;

    // 과제 테이블
    private JTable projTable;
    private DefaultTableModel projTableModel;

    // 검색 후 정렬용 리스트
    private List<ProjectDTO> currentProjList = new ArrayList<>();

    public AdminUI() {
        SwingUtilities.invokeLater(this::showMenu);
    }

    private void showMenu() {
        frame = new JFrame("관리자 모드");
        frame.setSize(600, 400);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel title = new JLabel("[관리자 모드]", SwingConstants.CENTER);
        title.setFont(new Font("맑은 고딕", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        JPanel btnPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        btnPanel.setBorder(BorderFactory.createEmptyBorder(10, 150, 10, 150));

        JButton orgBtn = new JButton("1. 등록된 기관 전체조회");
        JButton projBtn = new JButton("2. 등록된 과제 전체조회");
        JButton exitBtn = new JButton("0. 종료");

        btnPanel.add(orgBtn);
        btnPanel.add(projBtn);
        btnPanel.add(exitBtn);

        frame.setLayout(new BorderLayout());
        frame.add(title, BorderLayout.NORTH);
        frame.add(btnPanel, BorderLayout.CENTER);

        // 버튼 이벤트
        orgBtn.addActionListener(e -> showOrganizationUI());
        projBtn.addActionListener(e -> showProjectUI());
        exitBtn.addActionListener(e -> exit());

        frame.setVisible(true);
    }

    // ------------------ 기관 UI ------------------
    private void showOrganizationUI() {
        JFrame orgFrame = new JFrame("등록 기관 조회");
        orgFrame.setSize(800, 500);
        orgFrame.setLocationRelativeTo(frame);
        orgFrame.setLayout(new BorderLayout());

        String[] columns = {"코드", "기관명", "유형", "사업자번호", "전화", "이메일", "주소", "아이디"};
        orgTableModel = new DefaultTableModel(columns, 0);
        orgTable = new JTable(orgTableModel);

        JScrollPane scroll = new JScrollPane(orgTable);
        orgFrame.add(scroll, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();
        JButton showAllBtn = new JButton("전체조회");
        JButton searchName = new JButton("기관명 검색");
        JButton searchType = new JButton("기관타입 검색");
        JButton searchAddr = new JButton("주소지 검색");
        JButton backBtn = new JButton("뒤로가기");

        btnPanel.add(showAllBtn);
        btnPanel.add(searchName);
        btnPanel.add(searchType);
        btnPanel.add(searchAddr);
        btnPanel.add(backBtn);

        orgFrame.add(btnPanel, BorderLayout.SOUTH);

        // 버튼 이벤트
        showAllBtn.addActionListener(e -> {
            try {
                updateOrgTable(dao.ListOrgan());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(orgFrame, "⚠️ 오류: " + ex.getMessage());
            }
        });
        searchName.addActionListener(e -> searchOrganizationInline("name"));
        searchType.addActionListener(e -> searchOrganizationInline("type"));
        searchAddr.addActionListener(e -> searchOrganizationInline("address"));
        backBtn.addActionListener(e -> orgFrame.dispose());

        // 초기 데이터 로드
        try {
            updateOrgTable(dao.ListOrgan());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(orgFrame, "⚠️ 오류: " + ex.getMessage());
        }

        orgFrame.setVisible(true);
    }

    private void updateOrgTable(List<OrganizationDTO> list) {
        orgTableModel.setRowCount(0);
        for (OrganizationDTO dto : list) {
            orgTableModel.addRow(new Object[]{
                    dto.getOrgCode(), dto.getOrgName(), dto.getOrgType(),
                    dto.getBizRegNo(), dto.getOrgTel(), dto.getOrgEmail(),
                    dto.getOrgAddress(), dto.getOrgId()
            });
        }
    }

    private void searchOrganizationInline(String field) {
        try {
            String key = JOptionPane.showInputDialog(frame, "조회할 " + field + " 입력 ▶");
            if (key == null || key.isBlank()) return;

            List<OrganizationDTO> list = switch (field) {
                case "name" -> dao.findByOrganName(key);
                case "type" -> dao.findByOrganType(key);
                case "address" -> dao.findByOrganAddr(key);
                default -> null;
            };

            if (list == null || list.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "(검색 결과가 없습니다)");
                return;
            }

            updateOrgTable(list);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "⚠️ 검색 오류: " + ex.getMessage());
        }
    }

    // ------------------ 과제 UI ------------------
    private void showProjectUI() {
        JFrame projFrame = new JFrame("등록 과제 조회");
        projFrame.setSize(900, 500);
        projFrame.setLocationRelativeTo(frame);
        projFrame.setLayout(new BorderLayout());

        String[] columns = {"코드", "기관명", "제목", "단계", "상태", "예산", "시작일", "종료일"};
        projTableModel = new DefaultTableModel(columns, 0);
        projTable = new JTable(projTableModel);

        JScrollPane scroll = new JScrollPane(projTable);
        projFrame.add(scroll, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();
        JButton showAllBtn = new JButton("전체조회");
        JButton searchTitle = new JButton("제목 검색");
        JButton searchStage = new JButton("단계별 검색");
        JButton searchStatus = new JButton("상태별 검색");
        JButton sortBudgetDesc = new JButton("예산 내림차순");
        JButton sortBudgetAsc = new JButton("예산 오름차순");
        JButton backBtn = new JButton("뒤로가기");

        btnPanel.add(showAllBtn);
        btnPanel.add(searchTitle);
        btnPanel.add(searchStage);
        btnPanel.add(searchStatus);
        btnPanel.add(sortBudgetDesc);
        btnPanel.add(sortBudgetAsc);
        btnPanel.add(backBtn);

        projFrame.add(btnPanel, BorderLayout.SOUTH);

        // 버튼 이벤트
        showAllBtn.addActionListener(e -> {
            try {
                updateProjTable(dao.ListProject());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(projFrame, "⚠️ 오류: " + ex.getMessage());
            }
        });
        searchTitle.addActionListener(e -> searchProjectInline("title"));
        searchStage.addActionListener(e -> searchProjectInline("stage"));
        searchStatus.addActionListener(e -> searchProjectInline("status"));
        sortBudgetDesc.addActionListener(e -> sortProjectBudgetDescInline());
        sortBudgetAsc.addActionListener(e -> sortProjectBudgetAscInline());
        backBtn.addActionListener(e -> projFrame.dispose());

        // 초기 데이터 로드
        try {
            updateProjTable(dao.ListProject());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(projFrame, "⚠️ 오류: " + ex.getMessage());
        }

        projFrame.setVisible(true);
    }

    private void updateProjTable(List<ProjectDTO> list) {
        projTableModel.setRowCount(0);
        if (list != null) currentProjList = new ArrayList<>(list); // 검색 후 저장
        for (ProjectDTO dto : list) {
            projTableModel.addRow(new Object[]{
                    dto.getProjectCode(), dto.getOrgName(), dto.getTitle(),
                    dto.getStage(), dto.getStatus(), dto.getBudget(),
                    dto.getStartDate(), dto.getEndDate()
            });
        }
    }

    private void searchProjectInline(String field) {
        try {
            String key = JOptionPane.showInputDialog(frame, "조회할 " + field + " 입력 ▶");
            if (key == null || key.isBlank()) return;

            List<ProjectDTO> list = switch (field) {
                case "title" -> dao.FindByProjectTitle(key);
                case "stage" -> dao.FindByProjectStage(key);
                case "status" -> dao.FindByProjectStatus(key);
                default -> null;
            };

            if (list == null || list.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "(검색 결과가 없습니다)");
                currentProjList.clear();
                updateProjTable(currentProjList);
                return;
            }

            updateProjTable(list);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "⚠️ 검색 오류: " + ex.getMessage());
        }
    }

    private void sortProjectBudgetDescInline() {
        try {
            if (currentProjList.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "(등록된 과제가 없습니다)");
                return;
            }
            currentProjList.sort((p1, p2) -> Long.compare(p2.getBudget(), p1.getBudget())); // 내림차순
            updateProjTable(currentProjList);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "⚠️ 예산 내림차순 정렬 오류: " + ex.getMessage());
        }
    }

    private void sortProjectBudgetAscInline() {
        try {
            if (currentProjList.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "(등록된 과제가 없습니다)");
                return;
            }
            currentProjList.sort((p1, p2) -> Long.compare(p1.getBudget(), p2.getBudget())); // 오름차순
            updateProjTable(currentProjList);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "⚠️ 예산 오름차순 정렬 오류: " + ex.getMessage());
        }
    }

    private void exit() {
        DBConn.close();
        System.exit(0);
    }
}
