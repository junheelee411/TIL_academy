package administrator;

import db.organization.OrganizationDTO;
import db.project.ProjectDTO;
import db.util.DBConn;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdminDAO {
    private final Connection conn = DBConn.getConnection();

    // ------------------- OrganizationDTO 조회 -------------------
    private List<OrganizationDTO> fetchOrganizations(String sql, String key) throws SQLException {
        List<OrganizationDTO> list = new ArrayList<>();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            if (key != null) pstmt.setString(1, "%" + key + "%");

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    OrganizationDTO dto = new OrganizationDTO();
                    dto.setOrgCode(rs.getString("org_code"));
                    dto.setOrgName(rs.getString("name"));
                    dto.setOrgType(rs.getString("type"));
                    dto.setBizRegNo(rs.getString("biz_reg_no"));
                    dto.setOrgTel(rs.getString("tel"));
                    dto.setOrgEmail(rs.getString("email"));
                    dto.setOrgAddress(rs.getString("address"));
                    dto.setOrgId(rs.getString("id"));
                    list.add(dto);
                }
            }
        }

        return list;
    }

    public List<OrganizationDTO> ListOrgan() throws SQLException {
        return fetchOrganizations(
                "SELECT org_code, name, type, biz_reg_no, tel, email, address, id FROM organization", null
        );
    }

    public List<OrganizationDTO> findByOrganName(String key) throws SQLException {
        return fetchOrganizations(
                "SELECT org_code, name, type, biz_reg_no, tel, email, address, id FROM organization WHERE name LIKE ?", key
        );
    }

    public List<OrganizationDTO> findByOrganType(String key) throws SQLException {
        return fetchOrganizations(
                "SELECT org_code, name, type, biz_reg_no, tel, email, address, id FROM organization WHERE type LIKE ?", key
        );
    }

    public List<OrganizationDTO> findByOrganAddr(String key) throws SQLException {
        return fetchOrganizations(
                "SELECT org_code, name, type, biz_reg_no, tel, email, address, id FROM organization WHERE address LIKE ?", key
        );
    }

    // ------------------- ProjectDTO 조회 -------------------
    private List<ProjectDTO> fetchProjects(String sql, String key) throws SQLException {
        List<ProjectDTO> list = new ArrayList<>();
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            if (key != null) pstmt.setString(1, "%" + key + "%");

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    ProjectDTO dto = new ProjectDTO();
                    dto.setProjectCode(rs.getString("project_code"));
                    dto.setOrgName(rs.getString("org_name")); // alias 컬럼명 사용
                    dto.setTitle(rs.getString("title"));
                    dto.setStage(rs.getString("stage"));
                    dto.setStatus(rs.getString("status"));
                    dto.setBudget(rs.getLong("budget"));
                    dto.setStartDate(rs.getDate("start_date"));
                    dto.setEndDate(rs.getDate("end_date"));
                    list.add(dto);
                }
            }
        }
        return list;
    }

    public List<ProjectDTO> ListProject() throws SQLException {
        return fetchProjects(
                "SELECT p.project_code, org.name AS org_name, p.title, p.stage, p.status, p.budget, p.start_date, p.end_date " +
                        "FROM project p JOIN organization org ON p.org_code = org.org_code", null
        );
    }

    public List<ProjectDTO> FindByProjectTitle(String key) throws SQLException {
        return fetchProjects(
                "SELECT p.project_code, org.name AS org_name, p.title, p.stage, p.status, p.budget, p.start_date, p.end_date " +
                        "FROM project p JOIN organization org ON p.org_code = org.org_code WHERE p.title LIKE ?", key
        );
    }

    public List<ProjectDTO> FindByProjectStage(String key) throws SQLException {
        return fetchProjects(
                "SELECT p.project_code, org.name AS org_name, p.title, p.stage, p.status, p.budget, p.start_date, p.end_date " +
                        "FROM project p JOIN organization org ON p.org_code = org.org_code WHERE p.stage LIKE ?", key
        );
    }

    public List<ProjectDTO> FindByProjectStatus(String key) throws SQLException {
        return fetchProjects(
                "SELECT p.project_code, org.name AS org_name, p.title, p.stage, p.status, p.budget, p.start_date, p.end_date " +
                        "FROM project p JOIN organization org ON p.org_code = org.org_code WHERE p.status LIKE ?", key
        );
    }

    public List<ProjectDTO> ListProjectBudget() throws SQLException {
        return fetchProjects(
                "SELECT p.project_code, org.name AS org_name, p.title, p.stage, p.status, p.budget, p.start_date, p.end_date " +
                        "FROM project p JOIN organization org ON p.org_code = org.org_code ORDER BY p.budget DESC", null
        );
    }
}
