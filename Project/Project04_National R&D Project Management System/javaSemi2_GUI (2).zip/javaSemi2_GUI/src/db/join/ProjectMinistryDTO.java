package db.join;

public class ProjectMinistryDTO { //과제_부처테이블
	private String pCode;
	private String mCode;
	
	public String getpCode() {
		return pCode;
	}
	public void setpCode(String pCode) {
		this.pCode = pCode;
	}
	public String getmCode() {
		return mCode;
	}
	public void setmCode(String mCode) {
		this.mCode = mCode;
	}
	
	
}
