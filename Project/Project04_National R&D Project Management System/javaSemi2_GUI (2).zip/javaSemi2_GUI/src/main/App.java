package main;
import userInterface.UI;

public class App {

	public static void main(String[] args) {
		new UI();
	}
}
