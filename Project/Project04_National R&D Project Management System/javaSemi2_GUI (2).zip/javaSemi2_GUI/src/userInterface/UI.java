package userInterface;

import db.organization.OrganizationDAO;
import db.organization.OrganizationDTO;
import db.organization.OrganizationDAOImpl;
import db.util.DBConn;

import javax.swing.*;
import java.awt.*;

public class UI {
    private AuthUI authUI;
    private ProjectUI projectUI;
    private MemberUI memberUI;
    private ResearcherUI researcherUI;
    private OrganizationDAO organizationDAO;

    private String loggedOrgCode;

    public UI() {
        organizationDAO = new OrganizationDAOImpl();
        authUI = new AuthUI(this);

        SwingUtilities.invokeLater(this::showHomeUI);
    }

    // 초기 홈 화면
    public void showHomeUI() {
        JFrame frame = new JFrame("국가 연구개발 프로젝트 관리 시스템");
        frame.setSize(500, 350);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());

        JLabel title = new JLabel("국가 연구개발 프로젝트 관리 시스템", SwingConstants.CENTER);
        title.setFont(new Font("맑은 고딕", Font.BOLD, 20));
        mainPanel.add(title, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new GridLayout(1, 2, 20, 10));
        btnPanel.setBorder(BorderFactory.createEmptyBorder(20, 60, 30, 60));
        JButton loginBtn = new JButton("로그인");
        JButton signupBtn = new JButton("회원가입");

        btnPanel.add(loginBtn);
        btnPanel.add(signupBtn);
        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        frame.add(mainPanel);
        frame.setVisible(true);

        loginBtn.addActionListener(e -> {
            frame.dispose();
            authUI.showSignInUI();
        });

        signupBtn.addActionListener(e -> {
            frame.dispose();
            authUI.showSignUpUI();
        });
    }

    // 로그인 성공 시
    public void onOrgLogin(String orgCode) {
        try {
            OrganizationDTO loginOrg = organizationDAO.selectRecordByCode(orgCode);
            if (loginOrg == null) {
                JOptionPane.showMessageDialog(null, "❌ 로그인 정보가 유효하지 않습니다.");
                return;
            }

            loggedOrgCode = loginOrg.getOrgCode();

            projectUI = new ProjectUI(this, loggedOrgCode);
            memberUI = new MemberUI(this, organizationDAO, loggedOrgCode);
            researcherUI = new ResearcherUI(this, loggedOrgCode);

            showOrgMainMenuGUI();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "⚠️ 데이터베이스 오류: " + e.getMessage());
        }
    }

    private void showOrgMainMenuGUI() {
        JFrame frame = new JFrame("기관 메인 메뉴");
        frame.setSize(400, 350);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton projectBtn = new JButton("1. 과제 관리");
        JButton memberBtn = new JButton("2. 회원 정보 관리");
        JButton researcherBtn = new JButton("3. 연구원 정보 관리");
        JButton logoutBtn = new JButton("로그아웃");
        JButton exitBtn = new JButton("종료");

        panel.add(projectBtn);
        panel.add(memberBtn);
        panel.add(researcherBtn);
        panel.add(logoutBtn);
        panel.add(exitBtn);

        frame.add(panel);
        frame.setVisible(true);

        projectBtn.addActionListener(e -> projectUI.showProjectUI());
        memberBtn.addActionListener(e -> memberUI.showMemberUI());
        researcherBtn.addActionListener(e -> researcherUI.showResearcherUI());

        logoutBtn.addActionListener(e -> {
            frame.dispose();
            showHomeUI();
        });

        exitBtn.addActionListener(e -> exit());
    }

    public void exit() {
        DBConn.close();
        System.exit(0);
    }
}
