package userInterface;

import db.fund.management.FundManagementDAO;
import db.fund.management.FundManagementDAOImpl;
import db.fund.management.FundManagementDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class Project_FundUI {
    private FundManagementDAO fundDAO = new FundManagementDAOImpl();
    private String projectCode; // 현재 프로젝트 코드

    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode;
    }

    public void showFundManagementUI(String pCode) {
        this.projectCode = pCode;

        JFrame frame = new JFrame("연구비 관리 - " + projectCode);
        frame.setSize(900, 500);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new java.awt.BorderLayout());

        // 테이블
        String[] columns = {"코드","연구원 코드","담당자","분류","사용일","금액","내용","업체","증빙","메모"};
        DefaultTableModel model = new DefaultTableModel(columns,0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // 버튼
        JPanel buttonPanel = new JPanel();
        JButton addBtn = new JButton("추가");
        JButton editBtn = new JButton("수정");
        JButton deleteBtn = new JButton("삭제");
        JButton refreshBtn = new JButton("갱신");
        JButton closeBtn = new JButton("닫기");
        buttonPanel.add(addBtn); buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn); buttonPanel.add(refreshBtn);
        buttonPanel.add(closeBtn);

        panel.add(scrollPane, java.awt.BorderLayout.CENTER);
        panel.add(buttonPanel, java.awt.BorderLayout.SOUTH);
        frame.add(panel);
        frame.setVisible(true);

        // 초기 데이터 로딩
        loadFundList(model);

        addBtn.addActionListener(e -> addFundGUI(model));
        editBtn.addActionListener(e -> editFundGUI(table, model));
        deleteBtn.addActionListener(e -> deleteFundGUI(table, model));
        refreshBtn.addActionListener(e -> loadFundList(model));
        closeBtn.addActionListener(e -> frame.dispose());
    }

    private void loadFundList(DefaultTableModel model) {
        model.setRowCount(0);
        try {
            List<FundManagementDTO> list = fundDAO.listRecord(projectCode);
            for(FundManagementDTO dto : list) {
                model.addRow(new Object[]{
                        dto.getFcode(),
                        dto.getRcode(),
                        dto.getCharger_name(),
                        dto.getCategory(),
                        dto.getDate_used(),
                        dto.getExpense(),
                        dto.getContent(),
                        dto.getVendor_name(),
                        dto.getProof_type(),
                        dto.getMemo()
                });
            }
            if(list.isEmpty()) JOptionPane.showMessageDialog(null, "등록된 연구비 사용 내역이 없습니다.");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "연구비 목록 조회 오류: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void addFundGUI(DefaultTableModel model) {
        try {
            String rcode = JOptionPane.showInputDialog("연구원 코드 입력:");
            if(rcode == null) return;
            String charger = JOptionPane.showInputDialog("담당자 입력:");
            if(charger == null) return;
            String category = JOptionPane.showInputDialog("분류 입력:");
            if(category == null) return;
            String dateUsed = JOptionPane.showInputDialog("사용일 입력 (YYYY-MM-DD):");
            if(dateUsed == null) return;
            String expenseStr = JOptionPane.showInputDialog("금액 입력:");
            if(expenseStr == null) return;
            long expense = Long.parseLong(expenseStr);
            String content = JOptionPane.showInputDialog("내용 입력:");
            String vendor = JOptionPane.showInputDialog("업체 입력:");
            String proof = JOptionPane.showInputDialog("증빙 입력:");
            String memo = JOptionPane.showInputDialog("메모 입력:");

            FundManagementDTO dto = new FundManagementDTO();
            dto.setPcode(projectCode);
            dto.setRcode(rcode);
            dto.setCharger_name(charger);
            dto.setCategory(category);
            dto.setDate_used(dateUsed);
            dto.setExpense(expense);
            dto.setContent(content);
            dto.setVendor_name(vendor);
            dto.setProof_type(proof);
            dto.setMemo(memo);

            fundDAO.insertRecord(dto);
            JOptionPane.showMessageDialog(null, "연구비 사용 내역 추가 완료!");
            loadFundList(model);

        } catch(NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "금액 입력이 잘못되었습니다.");
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(null, "추가 실패: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void editFundGUI(JTable table, DefaultTableModel model) {
        int selectedRow = table.getSelectedRow();
        if(selectedRow == -1) { JOptionPane.showMessageDialog(null,"수정할 항목을 선택해주세요."); return; }

        String fcode = table.getValueAt(selectedRow,0).toString();
        try {
            FundManagementDTO dto = fundDAO.findByFundCode(fcode);
            if(dto == null || !dto.getPcode().equals(projectCode)) {
                JOptionPane.showMessageDialog(null,"수정 권한이 없거나 존재하지 않는 항목입니다.");
                return;
            }

            String rcode = JOptionPane.showInputDialog("연구원 코드 입력:", dto.getRcode());
            if(rcode == null) return;
            String charger = JOptionPane.showInputDialog("담당자 입력:", dto.getCharger_name());
            if(charger == null) return;
            String category = JOptionPane.showInputDialog("분류 입력:", dto.getCategory());
            if(category == null) return;
            String dateUsed = JOptionPane.showInputDialog("사용일 입력 (YYYY-MM-DD):", dto.getDate_used());
            if(dateUsed == null) return;
            String expenseStr = JOptionPane.showInputDialog("금액 입력:", dto.getExpense());
            if(expenseStr == null) return;
            long expense = Long.parseLong(expenseStr);
            String content = JOptionPane.showInputDialog("내용 입력:", dto.getContent());
            String vendor = JOptionPane.showInputDialog("업체 입력:", dto.getVendor_name());
            String proof = JOptionPane.showInputDialog("증빙 입력:", dto.getProof_type());
            String memo = JOptionPane.showInputDialog("메모 입력:", dto.getMemo());

            dto.setRcode(rcode);
            dto.setCharger_name(charger);
            dto.setCategory(category);
            dto.setDate_used(dateUsed);
            dto.setExpense(expense);
            dto.setContent(content);
            dto.setVendor_name(vendor);
            dto.setProof_type(proof);
            dto.setMemo(memo);

            fundDAO.updateRecord(dto);
            JOptionPane.showMessageDialog(null,"연구비 수정 완료!");
            loadFundList(model);

        } catch(NumberFormatException ex) {
            JOptionPane.showMessageDialog(null,"금액 입력이 잘못되었습니다.");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null,"수정 실패: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void deleteFundGUI(JTable table, DefaultTableModel model) {
        int selectedRow = table.getSelectedRow();
        if(selectedRow == -1) { JOptionPane.showMessageDialog(null,"삭제할 항목을 선택해주세요."); return; }

        String fcode = table.getValueAt(selectedRow,0).toString();
        try {
            FundManagementDTO dto = fundDAO.findByFundCode(fcode);
            if(dto == null || !dto.getPcode().equals(projectCode)) {
                JOptionPane.showMessageDialog(null,"삭제 권한이 없거나 존재하지 않는 항목입니다.");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(null,"정말 삭제하시겠습니까?","삭제 확인",JOptionPane.YES_NO_OPTION);
            if(confirm == JOptionPane.YES_OPTION) {
                fundDAO.deleteRecord(fcode);
                JOptionPane.showMessageDialog(null,"삭제 완료!");
                loadFundList(model);
            }

        } catch(Exception e) {
            JOptionPane.showMessageDialog(null,"삭제 실패: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
