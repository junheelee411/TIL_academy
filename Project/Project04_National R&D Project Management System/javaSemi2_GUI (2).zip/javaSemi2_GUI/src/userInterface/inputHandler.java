package userInterface;

import javax.swing.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class inputHandler {

    private static String phoneRegex = "^\\d{2,3}-\\d{3,4}-\\d{4}$";
    private static String brnRegex = "^\\d{3}-\\d{2}-\\d{5}$";

    private static String showInputDialog(String message) {
        return JOptionPane.showInputDialog(null, message, "입력", JOptionPane.PLAIN_MESSAGE);
    }

    // -----------------------------
    // 1. 필수 입력
    // -----------------------------
    public static String getRequiredInput(String prompt) throws InputCancelledException {
        while (true) {
            String input = showInputDialog(prompt);
            if (input == null) throw new InputCancelledException();
            if (!input.trim().isEmpty()) return input.trim();
            JOptionPane.showMessageDialog(null, "⚠️ 필수 입력 항목입니다.");
        }
    }

    // 필수 입력 + 기본값
    public static String getRequiredInput(String prompt, String defaultValue) throws InputCancelledException {
        String input = showInputDialog(prompt + "\n(기존 값: " + defaultValue + ")");
        if (input == null) throw new InputCancelledException();
        return input.trim().isEmpty() ? defaultValue : input.trim();
    }

    // -----------------------------
    // 2. 선택 입력
    // -----------------------------
    public static String getOptionalInput(String prompt) throws InputCancelledException {
        String input = showInputDialog(prompt);
        if (input == null) throw new InputCancelledException();
        return input.trim();
    }

    public static String getOptionalInput(String prompt, String defaultValue) throws InputCancelledException {
        String input = showInputDialog(prompt + "\n(기존 값: " + defaultValue + ")");
        if (input == null) throw new InputCancelledException();
        return input.trim().isEmpty() ? defaultValue : input.trim();
    }

    // -----------------------------
    // 3. 전화번호 입력
    // -----------------------------
    public static String getRequiredTelInput(String prompt) throws InputCancelledException {
        while (true) {
            String input = getRequiredInput(prompt);
            if (input.matches(phoneRegex)) return input;
            JOptionPane.showMessageDialog(null, "⚠️ 전화번호 형식이 올바르지 않습니다.\n예: 010-1234-5678");
        }
    }

    public static String getOptionalTelInput(String prompt) throws InputCancelledException {
        while (true) {
            String input = showInputDialog(prompt);
            if (input == null) throw new InputCancelledException();
            if (input.trim().isEmpty()) return input;
            if (input.matches(phoneRegex)) return input;
            JOptionPane.showMessageDialog(null, "⚠️ 전화번호 형식이 올바르지 않습니다.");
        }
    }
    
    public static String getRequiredTelInput(String prompt, String defaultValue) throws InputCancelledException {
        while (true) {
            String input = showInputDialog(prompt + "\n(기존 값: " + defaultValue + ")");
            if (input == null) throw new InputCancelledException();
            input = input.trim().isEmpty() ? defaultValue : input.trim();
            if (input.matches(phoneRegex)) return input;
            JOptionPane.showMessageDialog(null, "⚠️ 전화번호 형식이 올바르지 않습니다.\n예: 010-1234-5678");
        }
    }

    // -----------------------------
    // 4. 날짜 입력
    // -----------------------------
    public static String getRequiredDateInput(String prompt) throws InputCancelledException {
        while (true) {
            String input = getRequiredInput(prompt);
            try {
                LocalDate.parse(input);
                return input;
            } catch (DateTimeParseException e) {
                JOptionPane.showMessageDialog(null, "⚠️ 올바른 날짜 형식이 아닙니다. (YYYY-MM-DD)");
            }
        }
    }

    public static String getRequiredDateInput(String prompt, String defaultValue) throws InputCancelledException {
        while (true) {
            String input = showInputDialog(prompt + "\n(기존 값: " + defaultValue + ")");
            if (input == null) throw new InputCancelledException();
            input = input.trim().isEmpty() ? defaultValue : input.trim();
            try {
                LocalDate.parse(input);
                return input;
            } catch (DateTimeParseException e) {
                JOptionPane.showMessageDialog(null, "⚠️ 올바른 날짜 형식이 아닙니다. (YYYY-MM-DD)");
            }
        }
    }

    public static String getOptionalDateInput(String prompt) throws InputCancelledException {
        while (true) {
            String input = showInputDialog(prompt);
            if (input == null) throw new InputCancelledException();
            if (input.trim().isEmpty()) return input;
            try {
                LocalDate.parse(input.trim());
                return input.trim();
            } catch (DateTimeParseException e) {
                JOptionPane.showMessageDialog(null, "⚠️ 올바른 날짜 형식이 아닙니다. (YYYY-MM-DD)");
            }
        }
    }

    public static String getOptionalDateInput(String prompt, String defaultValue) throws InputCancelledException {
        while (true) {
            String input = showInputDialog(prompt + "\n(기존 값: " + defaultValue + ")");
            if (input == null) throw new InputCancelledException();
            input = input.trim().isEmpty() ? defaultValue : input.trim();
            try {
                LocalDate.parse(input);
                return input;
            } catch (DateTimeParseException e) {
                JOptionPane.showMessageDialog(null, "⚠️ 올바른 날짜 형식이 아닙니다. (YYYY-MM-DD)");
            }
        }
    }

    // -----------------------------
    // 5. 사업자등록번호 입력
    // -----------------------------
    public static String getRequiredBizRegInput(String prompt) throws InputCancelledException {
        while (true) {
            String input = getRequiredInput(prompt);
            if (input.matches(brnRegex)) return input;
            JOptionPane.showMessageDialog(null, "⚠️ 형식 오류: 123-45-67890");
        }
    }

    public static String getOptionalBizRegInput(String prompt) throws InputCancelledException {
        while (true) {
            String input = showInputDialog(prompt);
            if (input == null) throw new InputCancelledException();
            if (input.trim().isEmpty()) return input;
            if (input.matches(brnRegex)) return input;
            JOptionPane.showMessageDialog(null, "⚠️ 형식 오류: 123-45-67890");
        }
    }

    public static boolean compareDateInput(String sDate, String eDate) throws Exception {
        var start = LocalDate.parse(sDate);
        var end = LocalDate.parse(eDate);
        return start.isBefore(end);
    }
}
