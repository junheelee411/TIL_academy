package userInterface;

import db.researcher.ResearcherDAO;
import db.researcher.ResearcherDAOImpl;
import db.researcher.ResearcherDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ResearcherUI {
    private UI ui;
    private ResearcherDAO researcherDAO;
    private String orgCode;

    public ResearcherUI(UI ui, String orgCode) {
        this.ui = ui;
        this.orgCode = orgCode;
        this.researcherDAO = new ResearcherDAOImpl();
    }

    public void showResearcherUI() {
        JFrame frame = new JFrame("연구원 관리 (" + orgCode + ")");
        frame.setSize(700, 500);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        // 테이블 모델
        String[] columns = {"연구원코드", "이름", "전화번호", "이메일"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel buttonPanel = new JPanel();
        JButton addBtn = new JButton("연구원 추가");
        JButton editBtn = new JButton("연구원 수정");
        JButton deleteBtn = new JButton("연구원 삭제");
        JButton closeBtn = new JButton("닫기");
        JButton exitBtn = new JButton("종료");

        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(closeBtn);
        buttonPanel.add(exitBtn);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        frame.add(panel);
        frame.setVisible(true);

        loadResearcherTable(model);

        // 버튼 이벤트
        addBtn.addActionListener(e -> addResearcherGUI(model));
        editBtn.addActionListener(e -> editResearcherGUI(table, model));
        deleteBtn.addActionListener(e -> deleteResearcherGUI(table, model));
        closeBtn.addActionListener(e -> frame.dispose());
        exitBtn.addActionListener(e -> ui.exit());
    }

    private void loadResearcherTable(DefaultTableModel model) {
        model.setRowCount(0); // 초기화
        try {
            List<ResearcherDTO> list = ((ResearcherDAOImpl) researcherDAO).listResearchersByOrg(orgCode);
            for (ResearcherDTO r : list) {
                model.addRow(new Object[]{r.getResearcherCode(), r.getName(), r.getTel(), r.getEmail()});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "⚠️ 연구원 목록 조회 실패: " + e.getMessage());
        }
    }

    private void addResearcherGUI(DefaultTableModel model) {
        try {
            String name = inputHandler.getRequiredInput("이름 입력:");
            String tel = inputHandler.getRequiredTelInput("전화번호 입력 (예: 010-1234-5678):");
            String email = inputHandler.getOptionalInput("이메일 입력:");

            ResearcherDTO dto = new ResearcherDTO();
            dto.setOrgCode(orgCode);
            dto.setName(name);
            dto.setTel(tel);
            dto.setEmail(email);

            researcherDAO.insertResearcherDAO(dto);
            JOptionPane.showMessageDialog(null, "✅ 연구원 등록 완료!");
            loadResearcherTable(model);

        } catch (InputCancelledException ex) {
            JOptionPane.showMessageDialog(null, "연구원 추가가 취소되었습니다.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "❌ 연구원 등록 실패: " + e.getMessage());
        }
    }


    private void editResearcherGUI(JTable table, DefaultTableModel model) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(null, "⚠️ 수정할 연구원을 선택해주세요.");
            return;
        }

        String code = table.getValueAt(row, 0).toString();
        try {
            ResearcherDTO dto = researcherDAO.selectResearcherByCode(code);
            if (!dto.getOrgCode().equals(orgCode)) {
                JOptionPane.showMessageDialog(null, "⚠️ 수정 불가: 다른 기관 소속 연구원입니다.");
                return;
            }

            String name = inputHandler.getRequiredInput("이름 입력:", dto.getName());
            String tel = inputHandler.getRequiredTelInput("전화번호 입력 (예: 010-1234-5678):", dto.getTel());
            String email = inputHandler.getOptionalInput("이메일 입력:", dto.getEmail());

            dto.setName(name);
            dto.setTel(tel);
            dto.setEmail(email);

            researcherDAO.updateResearcherDAO(dto);
            JOptionPane.showMessageDialog(null, "✅ 연구원 정보 수정 완료!");
            loadResearcherTable(model);

        } catch (InputCancelledException ex) {
            JOptionPane.showMessageDialog(null, "연구원 수정이 취소되었습니다.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "❌ 연구원 수정 실패: " + e.getMessage());
        }
    }


    private void deleteResearcherGUI(JTable table, DefaultTableModel model) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(null, "⚠️ 삭제할 연구원을 선택해주세요.");
            return;
        }

        String code = table.getValueAt(row, 0).toString();
        try {
            ResearcherDTO dto = researcherDAO.selectResearcherByCode(code);
            if (!dto.getOrgCode().equals(orgCode)) {
                JOptionPane.showMessageDialog(null, "⚠️ 삭제 불가: 다른 기관 소속 연구원입니다.");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(null, "정말 삭제하시겠습니까?", "연구원 삭제", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                researcherDAO.deleteResearcherDAO(code);
                JOptionPane.showMessageDialog(null, "✅ 연구원 삭제 완료!");
                loadResearcherTable(model);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "❌ 연구원 삭제 실패: " + e.getMessage());
        }
    }
}
