package userInterface;

import db.organization.OrganizationDAO;
import db.organization.OrganizationDTO;
import db.organization.OrganizationDAOImpl;

import javax.swing.*;
import java.awt.*;

import administrator.AdminUI;

public class AuthUI {
    private UI ui;
    private OrganizationDAO orgDAO = new OrganizationDAOImpl();

    public AuthUI(UI ui) {
        this.ui = ui;
    }

    public void showSignInUI() {
        JFrame frame = new JFrame("로그인");
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        JLabel idLabel = new JLabel("아이디:");
        JTextField idField = new JTextField();
        JLabel pwLabel = new JLabel("비밀번호:");
        JPasswordField pwField = new JPasswordField();
        JButton loginBtn = new JButton("로그인");
        JButton backBtn = new JButton("뒤로가기");

        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.add(idLabel); panel.add(idField);
        panel.add(pwLabel); panel.add(pwField);
        panel.add(loginBtn); panel.add(backBtn);

        frame.add(panel);
        frame.setVisible(true);

        loginBtn.addActionListener(e -> {
            String id = idField.getText().trim();
            String pw = new String(pwField.getPassword());

            if ("admin".equals(id) && "admin$!".equals(pw)) {
                frame.dispose();
                new AdminUI();
                return;
            }

            try {
                OrganizationDTO org = orgDAO.selectRecord(id);
                if (org == null || !org.getOrgPwd().equals(pw)) {
                    JOptionPane.showMessageDialog(frame, "⚠️ 아이디 또는 비밀번호가 잘못 되었습니다.");
                    return;
                }

                JOptionPane.showMessageDialog(frame, "[기관명] ▶ " + org.getOrgName());
                frame.dispose();
                ui.onOrgLogin(org.getOrgCode());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "⚠️ 로그인 오류: " + ex.getMessage());
            }
        });

        backBtn.addActionListener(e -> {
            frame.dispose();
            ui.showHomeUI();
        });
    }

    public void showSignUpUI() {
        JFrame frame = new JFrame("회원가입");
        frame.setSize(300, 200);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(2, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton registerBtn = new JButton("회원가입 진행");
        JButton backBtn = new JButton("뒤로가기");

        panel.add(registerBtn);
        panel.add(backBtn);

        frame.add(panel);
        frame.setVisible(true);

        // 회원가입 버튼
        registerBtn.addActionListener(e -> {
            try {
                // 필수 입력들 — inputHandler 이용
                String id = inputHandler.getRequiredInput("아이디를 입력하세요.");
                if (orgDAO.selectRecord(id) != null) {
                    JOptionPane.showMessageDialog(frame, "⚠️ 이미 사용 중인 아이디입니다.");
                    return;
                }
                String pw = inputHandler.getRequiredInput("비밀번호를 입력하세요.");
                String name = inputHandler.getRequiredInput("기관명을 입력하세요.");
                String type = inputHandler.getRequiredInput("기관 유형을 입력하세요.");
                String biz = inputHandler.getRequiredBizRegInput("사업자번호(123-45-67890)를 입력하세요.");
                if (orgDAO.isBizRegNoExists(biz)) {
                    JOptionPane.showMessageDialog(frame, "⚠️ 이미 등록된 사업자 번호입니다.");
                    return;
                }
                String tel = inputHandler.getRequiredTelInput("전화번호(010-0000-0000)를 입력하세요.");
                String email = inputHandler.getRequiredInput("이메일을 입력하세요.");
                String addr = inputHandler.getRequiredInput("주소를 입력하세요.");            

                // DTO 저장
                OrganizationDTO dto = new OrganizationDTO();
                dto.setOrgId(id);
                dto.setOrgPwd(pw);
                dto.setOrgName(name);
                dto.setOrgType(type);
                dto.setBizRegNo(biz);
                dto.setOrgTel(tel);
                dto.setOrgEmail(email);
                dto.setOrgAddress(addr);

                orgDAO.insertOrganization(dto);

                JOptionPane.showMessageDialog(frame, "✅ 회원가입이 성공적으로 완료되었습니다.");
                frame.dispose();
                showSignInUI();

            } catch (InputCancelledException ex) {
                JOptionPane.showMessageDialog(frame, "⚠️ 회원가입이 취소되었습니다.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "⚠️ 회원가입 오류: " + ex.getMessage());
            }
        });

        // 뒤로가기
        backBtn.addActionListener(e -> {
            frame.dispose();
            ui.showHomeUI();
        });
    }

}
