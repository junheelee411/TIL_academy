package userInterface;

import db.organization.OrganizationDAO;
import db.organization.OrganizationDTO;

import javax.swing.*;
import java.awt.*;

public class MemberUI {
    private UI ui;
    private OrganizationDAO organizationDAO;
    private String loggedOrgCode;

    public MemberUI(UI ui, OrganizationDAO organizationDAO, String loggedOrgCode) {
        this.ui = ui;
        this.organizationDAO = organizationDAO;
        this.loggedOrgCode = loggedOrgCode;
    }

    public void showMemberUI() {
        JFrame frame = new JFrame("회원 정보 관리");
        frame.setSize(500, 400);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        JTextArea infoArea = new JTextArea();
        infoArea.setEditable(false);
        infoArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(infoArea);

        JPanel buttonPanel = new JPanel();
        JButton editBtn = new JButton("정보 수정");
        JButton closeBtn = new JButton("닫기");
        JButton exitBtn = new JButton("종료");

        buttonPanel.add(editBtn);
        buttonPanel.add(closeBtn);
        buttonPanel.add(exitBtn);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        frame.add(panel);
        frame.setVisible(true);

        loadMemberInfo(infoArea);

        editBtn.addActionListener(e -> editMemberInfoGUI(infoArea));
        closeBtn.addActionListener(e -> frame.dispose());
        exitBtn.addActionListener(e -> ui.exit());
    }

    private void loadMemberInfo(JTextArea infoArea) {
        try {
            OrganizationDTO dto = organizationDAO.selectRecordByCode(loggedOrgCode);
            if (dto == null) {
                infoArea.setText("❌ 회원 정보가 존재하지 않습니다.");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.append("===== 회원 정보 =====\n");
            sb.append(String.format("ID        : %s%n", dto.getOrgId()));
            sb.append(String.format("이름      : %s%n", dto.getOrgName()));
            sb.append(String.format("기관 유형 : %s%n", dto.getOrgType()));
            sb.append(String.format("사업자번호: %s%n", dto.getBizRegNo()));
            sb.append(String.format("전화번호  : %s%n", dto.getOrgTel()));
            sb.append(String.format("이메일    : %s%n", dto.getOrgEmail()));
            sb.append(String.format("주소      : %s%n", dto.getOrgAddress()));
            sb.append("====================\n");

            infoArea.setText(sb.toString());
        } catch (Exception e) {
            infoArea.setText("⚠️ 회원 정보 조회 실패: " + e.getMessage());
        }
    }

    private void editMemberInfoGUI(JTextArea infoArea) {
        try {
            OrganizationDTO dto = organizationDAO.selectRecordByCode(loggedOrgCode);
            if (dto == null) {
                JOptionPane.showMessageDialog(null, "❌ 회원 정보가 존재하지 않습니다.");
                return;
            }

            JTextField nameField = new JTextField(dto.getOrgName());
            JTextField typeField = new JTextField(dto.getOrgType());
            JTextField telField = new JTextField(dto.getOrgTel());
            JTextField emailField = new JTextField(dto.getOrgEmail());
            JTextField addressField = new JTextField(dto.getOrgAddress());

            Object[] message = {
                    "이름:", nameField,
                    "기관 유형:", typeField,
                    "사업자번호: " + dto.getBizRegNo(),
                    "전화번호:", telField,
                    "이메일:", emailField,
                    "주소:", addressField
            };

            int option = JOptionPane.showConfirmDialog(null, message, "회원 정보 수정", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                dto.setOrgName(nameField.getText());
                dto.setOrgType(typeField.getText());
                dto.setOrgTel(telField.getText());
                dto.setOrgEmail(emailField.getText());
                dto.setOrgAddress(addressField.getText());

                organizationDAO.updateOrganization(dto);
                JOptionPane.showMessageDialog(null, "✅ 회원 정보 수정 완료!");
                loadMemberInfo(infoArea);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "⚠️ 회원 정보 수정 실패: " + e.getMessage());
        }
    }
}
