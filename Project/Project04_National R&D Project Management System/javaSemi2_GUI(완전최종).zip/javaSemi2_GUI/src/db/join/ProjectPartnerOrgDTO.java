package db.join;

//과제_협약기관
public class ProjectPartnerOrgDTO { 
	private String pCode;
	private String poCode;
	
	public String getpCode() {
		return pCode;
	}
	public void setpCode(String pCode) {
		this.pCode = pCode;
	}
	public String getPoCode() {
		return poCode;
	}
	public void setPoCode(String poCode) {
		this.poCode = poCode;
	}
	
	
	
}
