package db.organization;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import db.util.DBConn;
import db.util.DBUtil;

public class OrganizationDAOImpl implements OrganizationDAO {
    private final Connection conn;

    public OrganizationDAOImpl() {
        this.conn = DBConn.getConnection();
    }

    @Override
    public void insertOrganization(OrganizationDTO dto) throws SQLException {
        String sql = """
            INSERT INTO organization(
                org_code, id, pwd, name, type, biz_reg_no, tel, email, address
            )
            VALUES('ORG_' || LPAD(seq_org_code.NEXTVAL, 3, '0'), ?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            conn.setAutoCommit(false);

            pstmt.setString(1, dto.getOrgId());
            pstmt.setString(2, dto.getOrgPwd());
            pstmt.setString(3, dto.getOrgName());
            pstmt.setString(4, dto.getOrgType());
            pstmt.setString(5, dto.getBizRegNo());
            pstmt.setString(6, dto.getOrgTel());
            pstmt.setString(7, dto.getOrgEmail());
            pstmt.setString(8, dto.getOrgAddress());

            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException e) {
            DBUtil.rollback(conn);
            throw e;
        } finally {
            try { conn.setAutoCommit(true); } catch (Exception ignored) {}
        }
    }

    @Override
    public void updateOrganization(OrganizationDTO dto) throws SQLException {
        String sql = """
            UPDATE organization
               SET name = ?, type = ?, biz_reg_no = ?, tel = ?, email = ?, address = ?
             WHERE org_code = ?
        """;

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            conn.setAutoCommit(false);

            pstmt.setString(1, dto.getOrgName());
            pstmt.setString(2, dto.getOrgType());
            pstmt.setString(3, dto.getBizRegNo());
            pstmt.setString(4, dto.getOrgTel());
            pstmt.setString(5, dto.getOrgEmail());
            pstmt.setString(6, dto.getOrgAddress());
            pstmt.setString(7, dto.getOrgCode());

            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException e) {
            DBUtil.rollback(conn);
            throw e;
        } finally {
            try { conn.setAutoCommit(true); } catch (Exception ignored) {}
        }
    }

    @Override
    public void deleteOrganization(String orgCode) throws SQLException {
        String sql = "DELETE FROM organization WHERE org_code = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            conn.setAutoCommit(false);

            pstmt.setString(1, orgCode);
            pstmt.executeUpdate();

            conn.commit();
        } catch (SQLException e) {
            DBUtil.rollback(conn);
            throw e;
        } finally {
            try { conn.setAutoCommit(true); } catch (Exception ignored) {}
        }
    }

    @Override
    public OrganizationDTO selectRecordByCode(String orgCode) throws SQLException {
        String sql = """
            SELECT org_code, id, pwd, name, type, biz_reg_no, tel, email, address
              FROM organization
             WHERE org_code = ?
        """;

        OrganizationDTO dto = null;

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, orgCode);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    dto = new OrganizationDTO();
                    dto.setOrgCode(rs.getString("org_code"));
                    dto.setOrgId(rs.getString("id"));
                    dto.setOrgPwd(rs.getString("pwd"));
                    dto.setOrgName(rs.getString("name"));
                    dto.setOrgType(rs.getString("type"));
                    dto.setBizRegNo(rs.getString("biz_reg_no"));
                    dto.setOrgTel(rs.getString("tel"));
                    dto.setOrgEmail(rs.getString("email"));
                    dto.setOrgAddress(rs.getString("address"));
                }
            }
        }

        return dto;
    }

    @Override
    public OrganizationDTO selectRecord(String orgId) throws SQLException {
        String sql = """
            SELECT org_code, id, pwd, name, type, biz_reg_no, tel, email, address
              FROM organization
             WHERE id = ?
        """;

        OrganizationDTO dto = null;

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, orgId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    dto = new OrganizationDTO();
                    dto.setOrgCode(rs.getString("org_code"));
                    dto.setOrgId(rs.getString("id"));
                    dto.setOrgPwd(rs.getString("pwd"));
                    dto.setOrgName(rs.getString("name"));
                    dto.setOrgType(rs.getString("type"));
                    dto.setBizRegNo(rs.getString("biz_reg_no"));
                    dto.setOrgTel(rs.getString("tel"));
                    dto.setOrgEmail(rs.getString("email"));
                    dto.setOrgAddress(rs.getString("address"));
                }
            }
        }

        return dto;
    }

    @Override
    public boolean isBizRegNoExists(String bizRegNo) throws SQLException {
        String sql = "SELECT COUNT(*) FROM organization WHERE biz_reg_no = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, bizRegNo);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        }
        return false;
    }
}
