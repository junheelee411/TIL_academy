package db.organization;

import java.sql.SQLException;

public interface OrganizationDAO {
    void insertOrganization(OrganizationDTO dto) throws SQLException;
    void updateOrganization(OrganizationDTO dto) throws SQLException;
    void deleteOrganization(String orgCode) throws SQLException;
    OrganizationDTO selectRecordByCode(String orgCode) throws SQLException;
    boolean isBizRegNoExists(String bizRegNo) throws SQLException;
	OrganizationDTO selectRecord(String orgId) throws SQLException;
}
