package db.fund.management;

import java.sql.SQLException;
import java.util.List;

public interface FundManagementDAO {
    void insertRecord(FundManagementDTO dto) throws SQLException;
    void updateRecord(FundManagementDTO dto) throws SQLException;
    void deleteRecord(String code) throws SQLException;

    FundManagementDTO findByFundCode(String code);
    boolean isProjectFundRecord(String pcode, String fcode);

    List<FundManagementDTO> listRecord();
    List<FundManagementDTO> listRecord(String code);
}
