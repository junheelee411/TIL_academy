package db.performance.management;

import db.util.DBConn;
import db.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PerformanceManagementDAO {
    private Connection conn = DBConn.getConnection();

    // 과제별 성과 목록 조회
    public List<PerformanceManagementDTO> performanceList(String projectCode) throws Exception {
        List<PerformanceManagementDTO> list = new ArrayList<>();
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            String sql = "SELECT performance_code AS code, name, category, content, p_date, memo " +
                         "FROM performance_management WHERE project_code = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, projectCode);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                PerformanceManagementDTO dto = new PerformanceManagementDTO();
                dto.setPerfCode(rs.getString("code"));
                dto.setName(rs.getString("name"));
                dto.setCategory(rs.getString("category"));
                dto.setContent(rs.getString("content"));
                dto.setpDate(rs.getString("p_date"));
                dto.setMemo(rs.getString("memo"));
                list.add(dto);
            }
        } finally {
            DBUtil.close(rs);
            DBUtil.close(pstmt);
        }

        return list;
    }

    // 성과 추가
    public int insertPerformance(PerformanceManagementDTO dto, String projectCode) throws Exception {
        int result = 0;
        try {
            conn.setAutoCommit(false);

            String sql = "INSERT INTO performance_management (performance_code, project_code, name, category, content, p_date, memo) " +
                         "VALUES ('PERF_' || LPAD(SEQ_PERFORMANCE_MANAGEMENT.NEXTVAL, 3, '0'), ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, projectCode);
            pstmt.setString(2, dto.getName());
            pstmt.setString(3, dto.getCategory());
            pstmt.setString(4, dto.getContent());
            pstmt.setDate(5, parseDate(dto.getpDate(), null)); //
            pstmt.setString(6, dto.getMemo());

            result = pstmt.executeUpdate();
            conn.commit();
        } catch (Exception e) {
            DBUtil.rollback(conn);
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
        return result;
    }

    // 성과 수정
    public int updatePerformance(PerformanceManagementDTO dto) throws Exception {
        int result = 0;
        String sql = "UPDATE performance_management SET name=?, category=?, content=?, p_date=TO_DATE(?, 'YYYYMMDD'), memo=? WHERE performance_code=?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            conn.setAutoCommit(false);
            pstmt.setString(1, dto.getName());
            pstmt.setString(2, dto.getCategory());
            pstmt.setString(3, dto.getContent());
            pstmt.setDate(4, parseDate(dto.getpDate(), null));
            pstmt.setString(5, dto.getMemo());
            pstmt.setString(6, dto.getPerfCode());

            result = pstmt.executeUpdate();
            conn.commit();
        } catch (Exception e) {
            DBUtil.rollback(conn);
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
        return result;
    }

    // 성과 삭제
    public int deletePerformance(String perfCode) throws Exception {
        int result = 0;
        String sql = "DELETE FROM performance_management WHERE performance_code = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            conn.setAutoCommit(false);
            pstmt.setString(1, perfCode);
            result = pstmt.executeUpdate();
            conn.commit();
        } catch (Exception e) {
            DBUtil.rollback(conn);
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
        return result;
    }

    private java.sql.Date parseDate(String dateStr, String existingDate) {
        if (dateStr == null || dateStr.isBlank()) dateStr = existingDate;
        if (dateStr == null || dateStr.isBlank()) return null;

        try {
            return java.sql.Date.valueOf(dateStr); // YYYY-MM-DD
        } catch (IllegalArgumentException e) {
            System.out.println("⚠️ 잘못된 날짜 형식: " + dateStr);
            return null;
        }
    }
}
