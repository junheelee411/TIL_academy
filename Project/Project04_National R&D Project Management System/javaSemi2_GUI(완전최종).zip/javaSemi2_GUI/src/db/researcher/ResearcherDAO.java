package db.researcher;

import java.sql.SQLException;
import java.util.List;

public interface ResearcherDAO {
    void insertResearcherDAO(ResearcherDTO dto) throws SQLException;
    void updateResearcherDAO(ResearcherDTO dto) throws SQLException;
    void deleteResearcherDAO(String researcherCode) throws SQLException;
    ResearcherDTO selectResearcherByCode(String researcherCode) throws SQLException;
    List<ResearcherDTO> listResearchersByOrg(String orgCode) throws SQLException;
    boolean isOrgIncludeRes(String orgCode, String researcherCode) throws SQLException;
}
