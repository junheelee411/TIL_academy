package userInterface;

import db.project.ProjectDAO;
import db.project.ProjectDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ProjectUI {
    private UI ui;
    private ProjectDAO projectDAO = new ProjectDAO();
    private String orgCode;

    // 세부 관리 UI 클래스
    private Project_PerformanceUI projectPerformance = new Project_PerformanceUI();
    private Project_FundUI projectFund = new Project_FundUI();          // 연구비 관리
    private Project_MilestoneUI projectMilestone = new Project_MilestoneUI();
    private Project_ResearcherUI projectResearcher = new Project_ResearcherUI();

    public ProjectUI(UI ui, String orgCode) {
        this.ui = ui;
        this.orgCode = orgCode;
    }

    public void showProjectUI() {
        JFrame frame = new JFrame("과제 관리 (" + orgCode + ")");
        frame.setSize(1100, 600);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());

        // JTable 설정
        String[] columns = {"과제코드", "과제명", "기관코드", "기관명", "단계", "상태", "예산"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(table);

        // 버튼 패널
        JPanel buttonPanel = new JPanel();
        JButton performanceBtn = new JButton("성과 관리");
        JButton fundBtn = new JButton("연구비 관리");
        JButton milestoneBtn = new JButton("마일스톤 관리");
        JButton researcherBtn = new JButton("연구원 관리");

        buttonPanel.add(performanceBtn);
        buttonPanel.add(fundBtn);
        buttonPanel.add(milestoneBtn);
        buttonPanel.add(researcherBtn);

        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        frame.add(mainPanel);

        // 데이터 로딩
        loadProjectData(model);

        // -------- 버튼 이벤트 --------
        performanceBtn.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                String pCode = (String) table.getValueAt(selectedRow, 0);
                projectPerformance.setProjectCode(pCode);
                projectPerformance.showPerformanceUI(pCode);
            } else {
                JOptionPane.showMessageDialog(frame, "과제를 선택해주세요.");
            }
        });

        fundBtn.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                String pCode = (String) table.getValueAt(selectedRow, 0);
                projectFund.setProjectCode(pCode);                     // 프로젝트 코드 전달
                projectFund.showFundManagementUI(pCode);               // 연구비 관리 UI 실행
            } else {
                JOptionPane.showMessageDialog(frame, "과제를 선택해주세요.");
            }
        });

        milestoneBtn.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                String pCode = (String) table.getValueAt(selectedRow, 0);
                projectMilestone.setProjectCode(pCode);
                projectMilestone.showMilestoneUI(pCode);
            } else {
                JOptionPane.showMessageDialog(frame, "과제를 선택해주세요.");
            }
        });

        researcherBtn.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                String pCode = (String) table.getValueAt(selectedRow, 0);
                String oCode = (String) table.getValueAt(selectedRow, 2);
                projectResearcher.setCode(pCode, oCode);
                projectResearcher.showProjectResearcherUI();
            } else {
                JOptionPane.showMessageDialog(frame, "과제를 선택해주세요.");
            }
        });

        frame.setVisible(true);
    }

    private void loadProjectData(DefaultTableModel model) {
        model.setRowCount(0);
        List<ProjectDTO> projects = projectDAO.getProjectsByOrganization(orgCode);
        for (ProjectDTO dto : projects) {
            Object[] row = {
                    dto.getProjectCode(),
                    dto.getTitle(),
                    dto.getOrgCode(),
                    dto.getOrgName(),
                    dto.getStage(),
                    dto.getStatus(),
                    dto.getBudget()
            };
            model.addRow(row);
        }
    }
}
