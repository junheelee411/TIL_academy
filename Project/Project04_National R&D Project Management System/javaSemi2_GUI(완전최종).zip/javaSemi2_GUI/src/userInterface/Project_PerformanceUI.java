package userInterface;

import db.performance.management.PerformanceManagementDAO;
import db.performance.management.PerformanceManagementDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class Project_PerformanceUI {
    private PerformanceManagementDAO dao = new PerformanceManagementDAO();
    private String projectCode;
    private String orgCode; // 필요시 사용

    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public void showPerformanceUI(String pCode) {
        JFrame frame = new JFrame("성과 관리 - " + projectCode);
        frame.setSize(900, 500);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new java.awt.BorderLayout());

        // 테이블
        String[] columns = {"코드", "제목", "카테고리", "내용", "발생일", "메모"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // 버튼
        JPanel buttonPanel = new JPanel();
        JButton addBtn = new JButton("추가");
        JButton editBtn = new JButton("수정");
        JButton deleteBtn = new JButton("삭제");
        JButton refreshBtn = new JButton("갱신");
        JButton closeBtn = new JButton("닫기");

        buttonPanel.add(addBtn); buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn); buttonPanel.add(refreshBtn);
        buttonPanel.add(closeBtn);

        panel.add(scrollPane, java.awt.BorderLayout.CENTER);
        panel.add(buttonPanel, java.awt.BorderLayout.SOUTH);
        frame.add(panel);
        frame.setVisible(true);

        // 초기 데이터 로딩
        loadPerformanceList(model);

        // 버튼 이벤트
        addBtn.addActionListener(e -> addPerformanceGUI(model));
        editBtn.addActionListener(e -> editPerformanceGUI(table, model));
        deleteBtn.addActionListener(e -> deletePerformanceGUI(table, model));
        refreshBtn.addActionListener(e -> loadPerformanceList(model));
        closeBtn.addActionListener(e -> frame.dispose());
    }

    private void loadPerformanceList(DefaultTableModel model) {
        model.setRowCount(0);
        try {
            List<PerformanceManagementDTO> list = dao.performanceList(projectCode);
            for (PerformanceManagementDTO dto : list) {
                model.addRow(new Object[]{
                        dto.getPerfCode(),
                        dto.getName(),
                        dto.getCategory(),
                        dto.getContent(),
                        dto.getpDate(),
                        dto.getMemo()
                });
            }
            if (list.isEmpty()) JOptionPane.showMessageDialog(null, "등록된 성과가 없습니다.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "성과 목록 조회 오류: " + e.getMessage());
        }
    }

    private void addPerformanceGUI(DefaultTableModel model) {
        try {
            String name = inputHandler.getRequiredInput("제목 입력:");
            String category = inputHandler.getRequiredInput("카테고리 입력:");
            String content = inputHandler.getOptionalInput("내용 입력:");
            String pDate = inputHandler.getRequiredDateInput("발생일 입력 (YYYY-MM-DD):");
            String memo = inputHandler.getOptionalInput("메모 입력:");

            PerformanceManagementDTO dto = new PerformanceManagementDTO();
            dto.setName(name); dto.setCategory(category);
            dto.setContent(content); dto.setpDate(pDate); dto.setMemo(memo);

            int result = dao.insertPerformance(dto, projectCode);
            JOptionPane.showMessageDialog(null, result > 0 ? "성과 추가 완료!" : "추가 실패");
            loadPerformanceList(model);

        } catch (InputCancelledException ex) {
            JOptionPane.showMessageDialog(null, "성과 추가가 취소되었습니다.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "성과 추가 오류: " + e.getMessage());
        }
    }

    private void editPerformanceGUI(JTable table, DefaultTableModel model) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "수정할 성과를 선택해주세요.");
            return;
        }

        String perfCode = table.getValueAt(selectedRow, 0).toString();
        try {
            PerformanceManagementDTO dto = dao.performanceList(projectCode)
                    .stream()
                    .filter(p -> p.getPerfCode().equals(perfCode))
                    .findFirst().orElse(null);

            if (dto == null) {
                JOptionPane.showMessageDialog(null, "해당 성과가 존재하지 않습니다.");
                return;
            }

            try {
                String name = inputHandler.getRequiredInput("제목 입력:", dto.getName());
                String category = inputHandler.getRequiredInput("카테고리 입력:", dto.getCategory());
                String content = inputHandler.getOptionalInput("내용 입력:", dto.getContent());
                String pDate = inputHandler.getRequiredDateInput("발생일 입력 (YYYY-MM-DD):", dto.getpDate());
                String memo = inputHandler.getOptionalInput("메모 입력:", dto.getMemo());

                dto.setName(name); dto.setCategory(category);
                dto.setContent(content); dto.setpDate(pDate); dto.setMemo(memo);

                int result = dao.updatePerformance(dto);
                JOptionPane.showMessageDialog(null, result > 0 ? "성과 수정 완료!" : "수정 실패");
                loadPerformanceList(model);

            } catch (InputCancelledException ex) {
                JOptionPane.showMessageDialog(null, "성과 수정이 취소되었습니다.");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "성과 수정 오류: " + e.getMessage());
        }
    }

    private void deletePerformanceGUI(JTable table, DefaultTableModel model) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "삭제할 성과를 선택해주세요.");
            return;
        }

        String perfCode = table.getValueAt(selectedRow, 0).toString();
        try {
            int confirm = JOptionPane.showConfirmDialog(null, "정말 삭제하시겠습니까?", "삭제 확인", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                int result = dao.deletePerformance(perfCode);
                JOptionPane.showMessageDialog(null, result > 0 ? "삭제 완료!" : "삭제 실패");
                loadPerformanceList(model);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "성과 삭제 오류: " + e.getMessage());
        }
    }
}
