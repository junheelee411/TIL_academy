package userInterface;

import db.researcher.ResearcherDAO;
import db.researcher.ResearcherDAOImpl;
import db.researcher.ResearcherDTO;
import db.researcher.role.ResearcherRoleDAO;
import db.researcher.role.ResearcherRoleDAOImpl;
import db.researcher.role.ResearcherRoleDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class Project_ResearcherUI {
    private ResearcherDAO researcherDAO;
    private ResearcherRoleDAO roleDAO;
    private String projectCode;
    private String orgCode;

    public Project_ResearcherUI() {
        this.researcherDAO = new ResearcherDAOImpl();
        this.roleDAO = new ResearcherRoleDAOImpl();
    }

    public void setCode(String pCode, String oCode) {
        this.projectCode = pCode;
        this.orgCode = oCode;
    }

    public void showProjectResearcherUI() {
        if (projectCode == null || projectCode.isBlank() || orgCode == null || orgCode.isBlank()) {
            JOptionPane.showMessageDialog(null, "⚠️ 프로젝트 코드 또는 기관 코드가 설정되지 않았습니다.");
            return;
        }

        JFrame frame = new JFrame("프로젝트 연구원 관리");
        frame.setSize(1000, 500);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        // 기관 소속 연구원 테이블
        String[] orgColumns = {"연구원코드", "이름"};
        DefaultTableModel orgModel = new DefaultTableModel(orgColumns, 0);
        JTable orgTable = new JTable(orgModel);
        JScrollPane orgScroll = new JScrollPane(orgTable);
        loadOrgResearchers(orgModel);

        // 프로젝트 배정 연구원 테이블
        String[] projColumns = {"연구원코드", "이름", "역할", "시작일", "종료일"};
        DefaultTableModel projModel = new DefaultTableModel(projColumns, 0);
        JTable projTable = new JTable(projModel);
        JScrollPane projScroll = new JScrollPane(projTable);
        loadProjectResearchers(projModel);

        // 버튼
        JPanel buttonPanel = new JPanel();
        JButton addBtn = new JButton("추가 →");
        JButton removeBtn = new JButton("← 제거");
        JButton refreshBtn = new JButton("갱신");
        JButton closeBtn = new JButton("닫기");
        buttonPanel.add(addBtn); buttonPanel.add(removeBtn);
        buttonPanel.add(refreshBtn); buttonPanel.add(closeBtn);

        JPanel centerPanel = new JPanel(new GridLayout(1, 2));
        centerPanel.add(orgScroll); centerPanel.add(projScroll);

        panel.add(centerPanel, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        frame.add(panel);
        frame.setVisible(true);

        // 추가 버튼 이벤트
        addBtn.addActionListener(e -> {
            int selRow = orgTable.getSelectedRow();
            if (selRow == -1) {
                JOptionPane.showMessageDialog(frame, "추가할 연구원을 선택해주세요.");
                return;
            }

            String rCode = (String) orgModel.getValueAt(selRow, 0);
            try {
                String role = inputHandler.getRequiredInput("역할 입력:");
                String start = inputHandler.getRequiredDateInput("시작일 입력 (YYYY-MM-DD):");
                String end = inputHandler.getRequiredDateInput("종료일 입력 (YYYY-MM-DD):");

                ResearcherRoleDTO dto = new ResearcherRoleDTO();
                dto.setProjectCode(projectCode);
                dto.setResearcherCode(rCode);
                dto.setRole(role);
                dto.setStartDate(start);
                dto.setEndDate(end);

                roleDAO.insertResearcherRoleDAO(dto);
                loadProjectResearchers(projModel);

            } catch (InputCancelledException ex) {
                JOptionPane.showMessageDialog(frame, "연구원 추가가 취소되었습니다.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "연구원 추가 오류: " + ex.getMessage());
            }
        });

        // 제거 버튼 이벤트
        removeBtn.addActionListener(e -> {
            int selRow = projTable.getSelectedRow();
            if (selRow == -1) {
                JOptionPane.showMessageDialog(frame, "삭제할 연구원을 선택해주세요.");
                return;
            }

            String rCode = (String) projModel.getValueAt(selRow, 0);
            int confirm = JOptionPane.showConfirmDialog(frame, "삭제하시겠습니까?", "확인", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    roleDAO.deleteResearcherRoleDAO(projectCode, rCode);
                    loadProjectResearchers(projModel);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "연구원 삭제 오류: " + ex.getMessage());
                }
            }
        });

        // 갱신 버튼 이벤트
        refreshBtn.addActionListener(e -> {
            loadOrgResearchers(orgModel);
            loadProjectResearchers(projModel);
        });

        // 닫기 버튼 이벤트
        closeBtn.addActionListener(e -> frame.dispose());
    }

    // 기관 소속 연구원 JTable 로드
    private void loadOrgResearchers(DefaultTableModel model) {
        model.setRowCount(0);
        if (orgCode == null || orgCode.isBlank()) {
            JOptionPane.showMessageDialog(null, "⚠️ 기관 코드가 설정되지 않아 연구원 조회가 불가능합니다.");
            return;
        }

        try {
            List<ResearcherDTO> list = researcherDAO.listResearchersByOrg(orgCode);
            if (list.isEmpty()) JOptionPane.showMessageDialog(null, "기관 소속 연구원이 없습니다.");
            for (ResearcherDTO r : list) model.addRow(new Object[]{r.getResearcherCode(), r.getName()});
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "기관 연구원 조회 오류: " + e.getMessage());
        }
    }

    // 프로젝트 배정 연구원 JTable 로드
    private void loadProjectResearchers(DefaultTableModel model) {
        model.setRowCount(0);
        if (projectCode == null || projectCode.isBlank()) return;

        try {
            List<ResearcherRoleDTO> list = roleDAO.listRole(projectCode);
            for (ResearcherRoleDTO dto : list) {
                ResearcherDTO rdto = researcherDAO.selectResearcherByCode(dto.getResearcherCode());
                model.addRow(new Object[]{
                        dto.getResearcherCode(),
                        rdto.getName(),
                        dto.getRole(),
                        dto.getStartDate().substring(0, 10),
                        dto.getEndDate().substring(0, 10)
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "프로젝트 연구원 조회 오류: " + e.getMessage());
        }
    }
}
