package userInterface;

import db.milestone.MilestoneDAO;
import db.milestone.MilestoneDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class Project_MilestoneUI {
    private MilestoneDAO milestoneDAO = new MilestoneDAO();
    private String projectCode;

    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode;
    }

    public void showMilestoneUI(String pCode) {
        JFrame frame = new JFrame("마일스톤 관리 - " + projectCode);
        frame.setSize(900, 500);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new java.awt.BorderLayout());

        // 테이블
        String[] columns = {"코드", "목표", "내용", "계획완료일", "실제완료일", "상태"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // 버튼
        JPanel buttonPanel = new JPanel();
        JButton addBtn = new JButton("추가");
        JButton editBtn = new JButton("수정");
        JButton deleteBtn = new JButton("삭제");
        JButton refreshBtn = new JButton("갱신");
        JButton closeBtn = new JButton("닫기");

        buttonPanel.add(addBtn); buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn); buttonPanel.add(refreshBtn);
        buttonPanel.add(closeBtn);

        panel.add(scrollPane, java.awt.BorderLayout.CENTER);
        panel.add(buttonPanel, java.awt.BorderLayout.SOUTH);
        frame.add(panel);
        frame.setVisible(true);

        // 초기 데이터 로딩
        loadMilestoneList(model);

        // 버튼 이벤트
        addBtn.addActionListener(e -> addMilestoneGUI(model));
        editBtn.addActionListener(e -> editMilestoneGUI(table, model));
        deleteBtn.addActionListener(e -> deleteMilestoneGUI(table, model));
        refreshBtn.addActionListener(e -> loadMilestoneList(model));
        closeBtn.addActionListener(e -> frame.dispose());
    }

    private void loadMilestoneList(DefaultTableModel model) {
        model.setRowCount(0);
        try {
            List<MilestoneDTO> list = milestoneDAO.listMilestoneByProject(projectCode);
            for(MilestoneDTO dto : list) {
                model.addRow(new Object[]{
                        dto.getMileCode(), dto.getName(), dto.getDesc(),
                        dto.getPeDate(), dto.getAeDate(), dto.getStatus()
                });
            }
            if(list.isEmpty()) JOptionPane.showMessageDialog(null, "등록된 마일스톤이 없습니다.");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "마일스톤 목록 조회 오류: " + e.getMessage());
        }
    }

    private void addMilestoneGUI(DefaultTableModel model) {
        try {
            String name = inputHandler.getRequiredInput("목표 입력:");
            String desc = inputHandler.getOptionalInput("내용 입력:");
            String peDate = inputHandler.getRequiredDateInput("계획완료일 입력 (YYYY-MM-DD):");
            String aeDate = inputHandler.getOptionalDateInput("실제완료일 입력 (YYYY-MM-DD):");
            String status = inputHandler.getRequiredInput("상태 입력:");

            MilestoneDTO dto = new MilestoneDTO();
            dto.setName(name); dto.setDesc(desc); dto.setPeDate(peDate);
            dto.setAeDate(aeDate); dto.setStatus(status);

            int result = milestoneDAO.insertMilestone(dto, projectCode);
            JOptionPane.showMessageDialog(null, result > 0 ? "마일스톤 추가 완료!" : "추가 실패");
            loadMilestoneList(model);

        } catch(InputCancelledException ex) {
            JOptionPane.showMessageDialog(null, "마일스톤 추가가 취소되었습니다.");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "마일스톤 추가 오류: " + e.getMessage());
        }
    }

    private void editMilestoneGUI(JTable table, DefaultTableModel model) {
        int selectedRow = table.getSelectedRow();
        if(selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "수정할 마일스톤을 선택해주세요.");
            return;
        }

        String mileCode = table.getValueAt(selectedRow, 0).toString();
        try {
            MilestoneDTO dto = milestoneDAO.listMilestoneByProject(projectCode)
                    .stream().filter(m -> m.getMileCode().equals(mileCode))
                    .findFirst().orElse(null);

            if(dto == null) {
                JOptionPane.showMessageDialog(null, "해당 마일스톤이 존재하지 않습니다.");
                return;
            }

            try {
                String name = inputHandler.getRequiredInput("목표 입력:", dto.getName());
                String desc = inputHandler.getOptionalInput("내용 입력:", dto.getDesc());
                String peDate = inputHandler.getRequiredDateInput("계획완료일 입력 (YYYY-MM-DD):", dto.getPeDate());
                String aeDate = inputHandler.getOptionalDateInput("실제완료일 입력 (YYYY-MM-DD):", dto.getAeDate());
                String status = inputHandler.getRequiredInput("상태 입력:", dto.getStatus());

                dto.setName(name); dto.setDesc(desc); dto.setPeDate(peDate);
                dto.setAeDate(aeDate); dto.setStatus(status);

                int result = milestoneDAO.updateMilestone(dto);
                JOptionPane.showMessageDialog(null, result > 0 ? "마일스톤 수정 완료!" : "수정 실패");
                loadMilestoneList(model);

            } catch(InputCancelledException ex) {
                JOptionPane.showMessageDialog(null, "마일스톤 수정이 취소되었습니다.");
            }

        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "마일스톤 수정 오류: " + e.getMessage());
        }
    }

    private void deleteMilestoneGUI(JTable table, DefaultTableModel model) {
        int selectedRow = table.getSelectedRow();
        if(selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "삭제할 마일스톤을 선택해주세요.");
            return;
        }

        String mileCode = table.getValueAt(selectedRow, 0).toString();
        try {
            int confirm = JOptionPane.showConfirmDialog(null, "정말 삭제하시겠습니까?", "삭제 확인", JOptionPane.YES_NO_OPTION);
            if(confirm == JOptionPane.YES_OPTION) {
                int result = milestoneDAO.deleteMilestone(mileCode);
                JOptionPane.showMessageDialog(null, result > 0 ? "삭제 완료!" : "삭제 실패");
                loadMilestoneList(model);
            }
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "마일스톤 삭제 오류: " + e.getMessage());
        }
    }
}
